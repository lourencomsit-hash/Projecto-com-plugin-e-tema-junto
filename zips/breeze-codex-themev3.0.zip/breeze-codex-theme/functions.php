<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once get_template_directory() . '/inc/theme-data.php';

function breeze_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support(
        'custom-logo',
        array(
            'height'      => 200,
            'width'       => 800,
            'flex-height' => true,
            'flex-width'  => true,
        )
    );
    add_theme_support(
        'html5',
        array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        )
    );

    register_nav_menus(
        array(
            'primary'             => __('Primary Menu', 'breeze-codex-theme'),
            'footer_explore'      => __('Footer Explore Menu', 'breeze-codex-theme'),
            'footer_destinations' => __('Footer Destinations Menu', 'breeze-codex-theme'),
        )
    );
}
add_action('after_setup_theme', 'breeze_theme_setup');

function breeze_enqueue_assets() {
    $version = wp_get_theme()->get('Version');

    wp_enqueue_style(
        'breeze-fonts',
        'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Manrope:wght@400;500;600;700&display=swap',
        array(),
        null
    );
    wp_enqueue_style(
        'breeze-main',
        get_template_directory_uri() . '/assets/css/styles.css',
        array('breeze-fonts'),
        $version
    );
    wp_enqueue_style(
        'breeze-destination',
        get_template_directory_uri() . '/assets/css/destination.css',
        array('breeze-main'),
        $version
    );
    wp_enqueue_style(
        'breeze-theme',
        get_stylesheet_uri(),
        array('breeze-destination'),
        $version
    );

    wp_enqueue_script(
        'breeze-main',
        get_template_directory_uri() . '/assets/js/main.js',
        array(),
        $version,
        true
    );
}
add_action('wp_enqueue_scripts', 'breeze_enqueue_assets');

function breeze_body_classes($classes) {
    if (!is_front_page()) {
        $classes[] = 'inner-page';
    }

    return $classes;
}
add_filter('body_class', 'breeze_body_classes');

function breeze_home_anchor_url($anchor) {
    return home_url('/#' . ltrim((string) $anchor, '#'));
}

function breeze_get_page_url_by_slug($slug, $fallback = '') {
    $slug = trim((string) $slug, '/');
    if ($slug === '') {
        return $fallback ? $fallback : home_url('/');
    }

    $page = get_page_by_path($slug, OBJECT, 'page');
    if ($page instanceof WP_Post) {
        return get_permalink($page);
    }

    return $fallback ? $fallback : home_url('/' . $slug . '/');
}

function breeze_get_theme_image($setting_key, $fallback = '') {
    $url = get_theme_mod($setting_key, '');
    if (!empty($url)) {
        return esc_url($url);
    }

    return $fallback;
}

function breeze_get_logo_url() {
    if (function_exists('has_custom_logo') && has_custom_logo()) {
        $logo_id = (int) get_theme_mod('custom_logo');
        $logo_url = wp_get_attachment_image_url($logo_id, 'full');
        if (!empty($logo_url)) {
            return $logo_url;
        }
    }

    $defaults = breeze_get_home_defaults();
    return $defaults['logo'];
}

function breeze_render_editor_content($raw_content) {
    $raw_content = (string) $raw_content;
    if (trim($raw_content) === '') {
        return '';
    }

    if (has_blocks($raw_content)) {
        return do_blocks($raw_content);
    }

    return do_shortcode($raw_content);
}

function breeze_strip_home_destinations_section($html) {
    $html = (string) $html;
    if ($html === '') {
        return $html;
    }

    // Remove the legacy Home destinations section to avoid duplicated destination blocks.
    $pattern = '/<section\b[^>]*\bid=(["\'])destinations\1[^>]*>.*?<\/section>/is';
    return (string) preg_replace($pattern, '', $html);
}

if (!class_exists('Breeze_Flat_Nav_Walker')) {
    class Breeze_Flat_Nav_Walker extends Walker_Nav_Menu {
        public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
            $atts = array();
            $atts['href'] = !empty($item->url) ? $item->url : '';

            if (!empty($item->target)) {
                $atts['target'] = $item->target;
            }
            if (!empty($item->xfn)) {
                $atts['rel'] = $item->xfn;
            }
            if (in_array('current-menu-item', (array) $item->classes, true)) {
                $atts['aria-current'] = 'page';
            }

            $attributes = '';
            foreach ($atts as $attr => $value) {
                if ($value === '') {
                    continue;
                }
                $attributes .= ' ' . $attr . '="' . esc_attr($value) . '"';
            }

            $title = apply_filters('the_title', $item->title, $item->ID);
            $output .= '<a' . $attributes . '>' . esc_html($title) . '</a>';
        }

        public function end_el(&$output, $item, $depth = 0, $args = null) {
        }
    }
}

function breeze_render_menu_links($links) {
    foreach ($links as $link) {
        $url = isset($link['url']) ? $link['url'] : '#';
        $label = isset($link['label']) ? $link['label'] : '';
        echo '<a href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
    }
}

function breeze_primary_fallback_links() {
    $is_home = is_front_page();

    return array(
        array(
            'label' => 'All Packages',
            'url'   => breeze_get_page_url_by_slug('packages', home_url('/packages/')),
        ),
        array(
            'label' => 'Discover Parks',
            'url'   => $is_home ? '#parks-showcase' : breeze_home_anchor_url('parks-showcase'),
        ),
        array(
            'label' => 'Contact',
            'url'   => $is_home ? '#contact' : breeze_home_anchor_url('contact'),
        ),
    );
}

function breeze_footer_explore_fallback_links() {
    return array(
        array('label' => 'Packages', 'url' => breeze_get_page_url_by_slug('packages', home_url('/packages/'))),
        array('label' => 'Why Tanzania', 'url' => breeze_home_anchor_url('parks-showcase')),
        array('label' => 'About', 'url' => breeze_get_page_url_by_slug('about', home_url('/about/'))),
        array('label' => 'Privacy Policy', 'url' => breeze_get_page_url_by_slug('privacy-policy', home_url('/privacy-policy/'))),
    );
}

function breeze_footer_destinations_fallback_links() {
    return array(
        array('label' => 'Serengeti', 'url' => breeze_get_page_url_by_slug('serengeti-national-park')),
        array('label' => 'Ngorongoro', 'url' => breeze_get_page_url_by_slug('ngorongoro-conservation-area')),
        array('label' => 'Tarangire', 'url' => breeze_get_page_url_by_slug('tarangire-national-park')),
        array('label' => 'Zanzibar', 'url' => breeze_get_page_url_by_slug('zanzibar')),
    );
}

function breeze_upsert_seed_page($definition, $menu_order = 0) {
    $slug = sanitize_title((string) $definition['slug']);
    $title = sanitize_text_field((string) $definition['title']);
    $content = isset($definition['content']) ? (string) $definition['content'] : '';
    $template = isset($definition['template']) ? (string) $definition['template'] : 'default';

    $existing = get_page_by_path($slug, OBJECT, 'page');
    $postarr = array(
        'post_title'   => $title,
        'post_name'    => $slug,
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_content' => $content,
        'menu_order'   => (int) $menu_order,
    );

    if ($existing instanceof WP_Post) {
        $postarr['ID'] = $existing->ID;
        $page_id = wp_update_post($postarr, true);
    } else {
        $page_id = wp_insert_post($postarr, true);
    }

    if (is_wp_error($page_id) || !$page_id) {
        return 0;
    }

    if ($template !== '' && $template !== 'default') {
        update_post_meta($page_id, '_wp_page_template', $template);
    } else {
        delete_post_meta($page_id, '_wp_page_template');
    }

    return (int) $page_id;
}

function breeze_ensure_seed_pages() {
    $definitions = breeze_get_seed_page_definitions();
    $page_ids = array();

    foreach ($definitions as $index => $definition) {
        $page_id = breeze_upsert_seed_page($definition, $index);
        if ($page_id > 0) {
            $page_ids[$definition['slug']] = $page_id;
        }
    }

    return $page_ids;
}

function breeze_clear_menu_items($menu_id) {
    $items = wp_get_nav_menu_items($menu_id, array('post_status' => 'any'));
    if (!is_array($items)) {
        return;
    }

    foreach ($items as $item) {
        wp_delete_post($item->ID, true);
    }
}

function breeze_ensure_primary_menu($page_ids) {
    $menu_name = 'Breeze Main Menu';
    $menu = wp_get_nav_menu_object($menu_name);
    if (!$menu) {
        $menu_id = wp_create_nav_menu($menu_name);
        if (is_wp_error($menu_id)) {
            return;
        }
    } else {
        $menu_id = (int) $menu->term_id;
    }

    breeze_clear_menu_items($menu_id);

    $primary_links = breeze_primary_fallback_links();
    $position = 1;
    foreach ($primary_links as $link) {
        wp_update_nav_menu_item(
            $menu_id,
            0,
            array(
                'menu-item-title'    => $link['label'],
                'menu-item-url'      => $link['url'],
                'menu-item-type'     => 'custom',
                'menu-item-status'   => 'publish',
                'menu-item-position' => $position,
            )
        );
        $position++;
    }

    if (!empty($page_ids) && is_array($page_ids)) {
        $pages_menu_name = 'Breeze Pages Menu';
        $pages_menu = wp_get_nav_menu_object($pages_menu_name);
        if (!$pages_menu) {
            $pages_menu_id = wp_create_nav_menu($pages_menu_name);
            if (!is_wp_error($pages_menu_id)) {
                $pages_menu = wp_get_nav_menu_object((int) $pages_menu_id);
            }
        }

        if ($pages_menu) {
            $pages_menu_id = (int) $pages_menu->term_id;
            breeze_clear_menu_items($pages_menu_id);

            $ordered_slugs = array(
                'home',
                'privacy-policy',
                'serengeti-national-park',
                'ngorongoro-conservation-area',
                'tarangire-national-park',
                'lake-manyara-national-park',
                'arusha-national-park',
                'ndutu-area',
                'zanzibar',
            );

            $position = 1;
            foreach ($ordered_slugs as $slug) {
                if (!isset($page_ids[$slug])) {
                    continue;
                }
                $page_id = (int) $page_ids[$slug];
                wp_update_nav_menu_item(
                    $pages_menu_id,
                    0,
                    array(
                        'menu-item-title'     => get_the_title($page_id),
                        'menu-item-object'    => 'page',
                        'menu-item-object-id' => $page_id,
                        'menu-item-type'      => 'post_type',
                        'menu-item-status'    => 'publish',
                        'menu-item-position'  => $position,
                    )
                );
                $position++;
            }
        }
    }

    $locations = get_theme_mod('nav_menu_locations', array());
    if (!is_array($locations)) {
        $locations = array();
    }
    $locations['primary'] = (int) $menu_id;
    set_theme_mod('nav_menu_locations', $locations);
}

function breeze_configure_reading_options($page_ids) {
    if (isset($page_ids['home'])) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', (int) $page_ids['home']);
        update_option('page_for_posts', 0);
    }

    if (isset($page_ids['privacy-policy'])) {
        update_option('wp_page_for_privacy_policy', (int) $page_ids['privacy-policy']);
    }
}

function breeze_bootstrap_site_on_activation() {
    $page_ids = breeze_ensure_seed_pages();
    breeze_configure_reading_options($page_ids);
    breeze_ensure_primary_menu($page_ids);
    flush_rewrite_rules(false);
    update_option('breeze_seed_content_version', '5');
}
add_action('after_switch_theme', 'breeze_bootstrap_site_on_activation');

function breeze_maybe_run_content_migration() {
    if (get_option('breeze_seed_content_version') === '5') {
        return;
    }

    breeze_bootstrap_site_on_activation();
}
add_action('after_setup_theme', 'breeze_maybe_run_content_migration', 20);

function breeze_customize_register($wp_customize) {
    $defaults = breeze_get_home_defaults();

    $wp_customize->add_section(
        'breeze_home_hero',
        array(
            'title'    => __('Breeze: Homepage Hero', 'breeze-codex-theme'),
            'priority' => 30,
        )
    );

    $wp_customize->add_setting(
        'breeze_home_hero_video_url',
        array(
            'default'           => $defaults['hero']['video_url'],
            'sanitize_callback' => 'esc_url_raw',
        )
    );
    $wp_customize->add_control(
        'breeze_home_hero_video_url',
        array(
            'label'   => __('Hero Video URL', 'breeze-codex-theme'),
            'section' => 'breeze_home_hero',
            'type'    => 'url',
        )
    );

    $wp_customize->add_setting(
        'breeze_home_hero_kicker',
        array(
            'default'           => $defaults['hero']['kicker'],
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    $wp_customize->add_control(
        'breeze_home_hero_kicker',
        array(
            'label'   => __('Hero Kicker', 'breeze-codex-theme'),
            'section' => 'breeze_home_hero',
            'type'    => 'text',
        )
    );

    $wp_customize->add_setting(
        'breeze_home_hero_title',
        array(
            'default'           => $defaults['hero']['title'],
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    $wp_customize->add_control(
        'breeze_home_hero_title',
        array(
            'label'   => __('Hero Title', 'breeze-codex-theme'),
            'section' => 'breeze_home_hero',
            'type'    => 'text',
        )
    );

    $wp_customize->add_setting(
        'breeze_home_hero_subtitle',
        array(
            'default'           => $defaults['hero']['subtitle'],
            'sanitize_callback' => 'wp_kses_post',
        )
    );
    $wp_customize->add_control(
        'breeze_home_hero_subtitle',
        array(
            'label'   => __('Hero Subtitle (supports basic HTML)', 'breeze-codex-theme'),
            'section' => 'breeze_home_hero',
            'type'    => 'textarea',
        )
    );

    $wp_customize->add_setting(
        'breeze_home_hero_button_text',
        array(
            'default'           => $defaults['hero']['button_text'],
            'sanitize_callback' => 'sanitize_text_field',
        )
    );
    $wp_customize->add_control(
        'breeze_home_hero_button_text',
        array(
            'label'   => __('Hero Button Text', 'breeze-codex-theme'),
            'section' => 'breeze_home_hero',
            'type'    => 'text',
        )
    );

    $wp_customize->add_setting(
        'breeze_home_hero_button_url',
        array(
            'default'           => $defaults['hero']['button_url'],
            'sanitize_callback' => 'breeze_sanitize_anchor_or_url',
        )
    );
    $wp_customize->add_control(
        'breeze_home_hero_button_url',
        array(
            'label'   => __('Hero Button URL', 'breeze-codex-theme'),
            'section' => 'breeze_home_hero',
            'type'    => 'text',
        )
    );

    $wp_customize->add_section(
        'breeze_home_images',
        array(
            'title'    => __('Breeze: Homepage Images', 'breeze-codex-theme'),
            'priority' => 31,
        )
    );

    for ($i = 1; $i <= 3; $i++) {
        $wp_customize->add_setting(
            'breeze_home_package_' . $i . '_image',
            array(
                'default'           => '',
                'sanitize_callback' => 'esc_url_raw',
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Image_Control(
                $wp_customize,
                'breeze_home_package_' . $i . '_image',
                array(
                    'label'   => sprintf(__('Package %d Image', 'breeze-codex-theme'), $i),
                    'section' => 'breeze_home_images',
                )
            )
        );
    }

    for ($i = 1; $i <= 7; $i++) {
        $wp_customize->add_setting(
            'breeze_home_park_' . $i . '_image',
            array(
                'default'           => '',
                'sanitize_callback' => 'esc_url_raw',
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Image_Control(
                $wp_customize,
                'breeze_home_park_' . $i . '_image',
                array(
                    'label'   => sprintf(__('Park Slide %d Image', 'breeze-codex-theme'), $i),
                    'section' => 'breeze_home_images',
                )
            )
        );
    }

    for ($i = 1; $i <= 7; $i++) {
        $wp_customize->add_setting(
            'breeze_home_destination_' . $i . '_image',
            array(
                'default'           => '',
                'sanitize_callback' => 'esc_url_raw',
            )
        );
        $wp_customize->add_control(
            new WP_Customize_Image_Control(
                $wp_customize,
                'breeze_home_destination_' . $i . '_image',
                array(
                    'label'   => sprintf(__('Destination Card %d Image', 'breeze-codex-theme'), $i),
                    'section' => 'breeze_home_images',
                )
            )
        );
    }

    $wp_customize->add_section(
        'breeze_footer_content',
        array(
            'title'    => __('Breeze: Footer', 'breeze-codex-theme'),
            'priority' => 32,
        )
    );

    $footer_fields = array(
        'breeze_footer_cta_kicker' => array('label' => 'Footer CTA Kicker', 'type' => 'text', 'default' => $defaults['footer']['cta_kicker'], 'sanitize' => 'sanitize_text_field'),
        'breeze_footer_cta_title' => array('label' => 'Footer CTA Title', 'type' => 'text', 'default' => $defaults['footer']['cta_title'], 'sanitize' => 'sanitize_text_field'),
        'breeze_footer_cta_button_text' => array('label' => 'Footer CTA Button Text', 'type' => 'text', 'default' => $defaults['footer']['cta_button_text'], 'sanitize' => 'sanitize_text_field'),
        'breeze_footer_cta_button_url' => array('label' => 'Footer CTA Button URL', 'type' => 'url', 'default' => $defaults['footer']['cta_button_url'], 'sanitize' => 'esc_url_raw'),
        'breeze_footer_brand_text' => array('label' => 'Footer Brand Description', 'type' => 'textarea', 'default' => $defaults['footer']['brand_text'], 'sanitize' => 'sanitize_textarea_field'),
        'breeze_footer_email' => array('label' => 'Footer Email', 'type' => 'email', 'default' => $defaults['footer']['email'], 'sanitize' => 'sanitize_email'),
        'breeze_footer_phone' => array('label' => 'Footer Phone', 'type' => 'text', 'default' => $defaults['footer']['phone'], 'sanitize' => 'sanitize_text_field'),
        'breeze_footer_location' => array('label' => 'Footer Location', 'type' => 'text', 'default' => $defaults['footer']['location'], 'sanitize' => 'sanitize_text_field'),
        'breeze_footer_extra_line' => array('label' => 'Footer Extra Line', 'type' => 'text', 'default' => $defaults['footer']['extra_line'], 'sanitize' => 'sanitize_text_field'),
        'breeze_footer_copyright' => array('label' => 'Footer Copyright', 'type' => 'text', 'default' => $defaults['footer']['copyright'], 'sanitize' => 'sanitize_text_field'),
        'breeze_footer_tagline' => array('label' => 'Footer Tagline', 'type' => 'text', 'default' => $defaults['footer']['tagline'], 'sanitize' => 'sanitize_text_field'),
    );

    foreach ($footer_fields as $key => $field) {
        $wp_customize->add_setting(
            $key,
            array(
                'default'           => $field['default'],
                'sanitize_callback' => $field['sanitize'],
            )
        );
        $wp_customize->add_control(
            $key,
            array(
                'label'   => __($field['label'], 'breeze-codex-theme'),
                'section' => 'breeze_footer_content',
                'type'    => $field['type'],
            )
        );
    }
}
add_action('customize_register', 'breeze_customize_register');

function breeze_sanitize_anchor_or_url($value) {
    $value = trim((string) $value);
    if ($value === '') {
        return '';
    }
    if (strpos($value, '#') === 0) {
        return '#' . sanitize_title(ltrim($value, '#'));
    }

    return esc_url_raw($value);
}

function breeze_destination_meta_fields() {
    return array(
        'hero_image_url'    => array('label' => 'Hero Image URL', 'type' => 'url'),
        'hero_eyebrow'      => array('label' => 'Hero Eyebrow', 'type' => 'text'),
        'hero_subtitle'     => array('label' => 'Hero Subtitle', 'type' => 'textarea'),
        'facts'             => array('label' => 'Facts (one per line)', 'type' => 'textarea'),
        'story_title'       => array('label' => 'Story Section Title', 'type' => 'text'),
        'story_1_title'     => array('label' => 'Story 1 Title', 'type' => 'text'),
        'story_1_text'      => array('label' => 'Story 1 Text', 'type' => 'textarea'),
        'story_2_title'     => array('label' => 'Story 2 Title', 'type' => 'text'),
        'story_2_text'      => array('label' => 'Story 2 Text', 'type' => 'textarea'),
        'story_3_title'     => array('label' => 'Story 3 Title', 'type' => 'text'),
        'story_3_text'      => array('label' => 'Story 3 Text', 'type' => 'textarea'),
        'gallery_1_url'     => array('label' => 'Gallery Image 1 URL', 'type' => 'url'),
        'gallery_1_alt'     => array('label' => 'Gallery Image 1 Alt', 'type' => 'text'),
        'gallery_2_url'     => array('label' => 'Gallery Image 2 URL', 'type' => 'url'),
        'gallery_2_alt'     => array('label' => 'Gallery Image 2 Alt', 'type' => 'text'),
        'gallery_3_url'     => array('label' => 'Gallery Image 3 URL', 'type' => 'url'),
        'gallery_3_alt'     => array('label' => 'Gallery Image 3 Alt', 'type' => 'text'),
        'gallery_4_url'     => array('label' => 'Gallery Image 4 URL', 'type' => 'url'),
        'gallery_4_alt'     => array('label' => 'Gallery Image 4 Alt', 'type' => 'text'),
        'gallery_5_url'     => array('label' => 'Gallery Image 5 URL', 'type' => 'url'),
        'gallery_5_alt'     => array('label' => 'Gallery Image 5 Alt', 'type' => 'text'),
        'cta_title'         => array('label' => 'CTA Title', 'type' => 'text'),
        'cta_text'          => array('label' => 'CTA Text', 'type' => 'textarea'),
        'cta_button_text'   => array('label' => 'CTA Button Text', 'type' => 'text'),
        'cta_button_url'    => array('label' => 'CTA Button URL', 'type' => 'url'),
    );
}

function breeze_add_destination_meta_box() {
    add_meta_box(
        'breeze_destination_fields',
        __('Destination Extra Fields', 'breeze-codex-theme'),
        'breeze_render_destination_meta_box',
        'page',
        'normal',
        'default'
    );
}
add_action('add_meta_boxes_page', 'breeze_add_destination_meta_box');

function breeze_render_destination_meta_box($post) {
    wp_nonce_field('breeze_destination_fields_nonce', 'breeze_destination_fields_nonce');

    $template = get_page_template_slug($post->ID);
    if ($template !== 'page-templates/destination-page.php') {
        echo '<p>' . esc_html__('Use this meta box with the template "Destination Page".', 'breeze-codex-theme') . '</p>';
        return;
    }

    $fields = breeze_destination_meta_fields();
    foreach ($fields as $key => $field) {
        $meta_key = '_breeze_dest_' . $key;
        $value = get_post_meta($post->ID, $meta_key, true);

        echo '<p>';
        echo '<label for="' . esc_attr($meta_key) . '"><strong>' . esc_html($field['label']) . '</strong></label><br>';

        if ($field['type'] === 'textarea') {
            echo '<textarea id="' . esc_attr($meta_key) . '" name="' . esc_attr($meta_key) . '" rows="3" style="width:100%;">' . esc_textarea($value) . '</textarea>';
        } else {
            $input_type = $field['type'] === 'url' ? 'url' : 'text';
            echo '<input type="' . esc_attr($input_type) . '" id="' . esc_attr($meta_key) . '" name="' . esc_attr($meta_key) . '" value="' . esc_attr($value) . '" style="width:100%;">';
        }

        echo '</p>';
    }
}

function breeze_save_destination_meta_box($post_id) {
    if (!isset($_POST['breeze_destination_fields_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['breeze_destination_fields_nonce'])), 'breeze_destination_fields_nonce')) {
        return;
    }

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }

    if (!current_user_can('edit_page', $post_id)) {
        return;
    }

    $fields = breeze_destination_meta_fields();
    foreach ($fields as $key => $field) {
        $meta_key = '_breeze_dest_' . $key;

        if (!isset($_POST[$meta_key])) {
            continue;
        }

        $raw = wp_unslash($_POST[$meta_key]);
        if ($field['type'] === 'url') {
            $value = esc_url_raw($raw);
        } elseif ($field['type'] === 'textarea') {
            $value = sanitize_textarea_field($raw);
        } else {
            $value = sanitize_text_field($raw);
        }

        if ($value === '') {
            delete_post_meta($post_id, $meta_key);
        } else {
            update_post_meta($post_id, $meta_key, $value);
        }
    }
}
add_action('save_post_page', 'breeze_save_destination_meta_box');

function breeze_get_destination_field($post_id, $field, $default = '') {
    $value = get_post_meta($post_id, '_breeze_dest_' . $field, true);
    if ($value !== '') {
        return $value;
    }
    return $default;
}

function breeze_get_destination_view_data($post_id) {
    $post = get_post($post_id);
    if (!$post instanceof WP_Post) {
        return array();
    }

    $defaults = breeze_get_destination_default($post->post_name);
    $featured_image = get_the_post_thumbnail_url($post_id, 'full');
    $hero_image = $featured_image ? $featured_image : breeze_get_destination_field($post_id, 'hero_image_url', $defaults['hero_image']);

    $content = trim((string) get_post_field('post_content', $post_id));
    $intro_paragraphs = array();
    if (isset($defaults['intro']) && is_array($defaults['intro'])) {
        $intro_paragraphs = $defaults['intro'];
    }

    $facts_raw = breeze_get_destination_field($post_id, 'facts', '');
    if ($facts_raw !== '') {
        $facts = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $facts_raw))));
    } else {
        $facts = isset($defaults['facts']) && is_array($defaults['facts']) ? $defaults['facts'] : array();
    }

    $gallery_classes = array('photo-xl', 'photo-wide', 'photo-mid', 'photo-mid', 'photo-sm');
    $gallery = array();
    for ($i = 1; $i <= 5; $i++) {
        $default_gallery_item = isset($defaults['gallery'][$i - 1]) ? $defaults['gallery'][$i - 1] : array();
        $default_gallery_url = isset($default_gallery_item['url']) ? $default_gallery_item['url'] : '';
        $default_gallery_alt = isset($default_gallery_item['alt']) ? $default_gallery_item['alt'] : '';

        $image_url = breeze_get_destination_field($post_id, 'gallery_' . $i . '_url', $default_gallery_url);
        $image_alt = breeze_get_destination_field($post_id, 'gallery_' . $i . '_alt', $default_gallery_alt);
        if ($image_url !== '') {
            $gallery[] = array(
                'class' => isset($default_gallery_item['class']) ? $default_gallery_item['class'] : $gallery_classes[$i - 1],
                'url'   => $image_url,
                'alt'   => $image_alt,
            );
        }
    }

    $stories = array();
    for ($i = 1; $i <= 3; $i++) {
        $default_story = isset($defaults['stories'][$i - 1]) ? $defaults['stories'][$i - 1] : array();
        $story_title = breeze_get_destination_field($post_id, 'story_' . $i . '_title', isset($default_story['title']) ? $default_story['title'] : '');
        $story_text = breeze_get_destination_field($post_id, 'story_' . $i . '_text', isset($default_story['text']) ? $default_story['text'] : '');
        if ($story_title !== '' || $story_text !== '') {
            $stories[] = array(
                'title' => $story_title,
                'text'  => $story_text,
            );
        }
    }

    return array(
        'title'           => get_the_title($post_id) !== '' ? get_the_title($post_id) : $defaults['title'],
        'hero_eyebrow'    => breeze_get_destination_field($post_id, 'hero_eyebrow', $defaults['eyebrow']),
        'hero_subtitle'   => breeze_get_destination_field($post_id, 'hero_subtitle', $defaults['hero_subtitle']),
        'hero_image'      => $hero_image,
        'has_content'     => $content !== '',
        'intro_paragraphs'=> $intro_paragraphs,
        'facts'           => $facts,
        'story_title'     => breeze_get_destination_field($post_id, 'story_title', $defaults['story_title']),
        'stories'         => $stories,
        'gallery_title'   => isset($defaults['gallery_title']) ? $defaults['gallery_title'] : 'Gallery',
        'gallery'         => $gallery,
        'cta_title'       => breeze_get_destination_field($post_id, 'cta_title', $defaults['cta_title']),
        'cta_text'        => breeze_get_destination_field($post_id, 'cta_text', $defaults['cta_text']),
        'cta_button_text' => breeze_get_destination_field($post_id, 'cta_button_text', $defaults['cta_button_text']),
        'cta_button_url'  => breeze_get_destination_field($post_id, 'cta_button_url', $defaults['cta_button_url']),
    );
}
