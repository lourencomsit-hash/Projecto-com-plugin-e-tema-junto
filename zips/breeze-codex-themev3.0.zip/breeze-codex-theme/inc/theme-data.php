<?php
if (!defined('ABSPATH')) {
    exit;
}

function breeze_get_home_defaults() {
    return array(
        'logo' => 'https://breezesafaris.com/wp-content/uploads/2025/11/cropped-Breeze_LOGO_1-removebg-preview.png',
        'hero' => array(
            'video_url' => 'https://breezesafaris.com/wp-content/uploads/2025/11/BREEZE-VIDEO-1-1.mp4',
            'kicker' => 'Explore • Discover • Relax',
            'title' => 'Tailor-made safaris created by two safari lovers living in Tanzania.',
            'subtitle' => "Experience breathtaking wildlife, authentic local guidance, and handpicked lodges.<br>Finish your journey in the tropical paradise of Zanzibar.",
            'button_text' => 'Start Your Journey',
            'button_url' => '#packages',
        ),
        'packages' => array(
            'head_kicker' => 'Featured Journeys',
            'head_title' => 'Safari Packages',
            'cards' => array(
                array(
                    'key' => 'ndutu-calving-6d',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Ndutu-1-scaled-1200x800.jpg',
                    'alt' => 'Ndutu migration wildlife safari',
                    'label' => 'December To March',
                    'title' => '6-Day Ndutu Great Migration Safari',
                    'text' => 'Track the migration in Ndutu and finish with a classic Ngorongoro Crater game-drive day.',
                    'price' => 'Starting from <strong>$2,310 pp</strong>',
                    'modal_price' => '<strong>Starting from:</strong> <strong>$2,310 per person</strong>',
                    'more_info_url' => '/packages/ndutu-calving-season-safari/',
                    'modal_image_alt' => 'Ndutu migration safari wildlife',
                    'inquiry_subject' => '6-Day%20Ndutu%20Great%20Migration%20Safari%20Inquiry',
                    'modal_points' => array(
                        'Best seasonal timing in Ndutu for migration movement and predator action.',
                        'Dedicated wildlife days across Ndutu plains and surrounding game-rich zones.',
                        'Full Ngorongoro Crater safari as a high-impact finale.',
                        "Stays include Arusha Planet Lodge, Ang'ata Migration Bologonja Camp and Embalakai Ngorongoro Camp.",
                        'Private 4x4 game-drive vehicle, park fees and guided safari logistics included.',
                    ),
                ),
                array(
                    'key' => 'luxury-migration-8d',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2025/11/pexels-followalice-667205-1024x706.jpg',
                    'alt' => 'Luxury migration safari in Tanzania',
                    'label' => 'Luxury Safari',
                    'title' => '8-Day Luxury Migration & Big Five Safari',
                    'text' => 'Tarangire, Northern Serengeti crossings and Ngorongoro, finished with Lake Manyara in one premium route.',
                    'price' => 'Starting from <strong>$6,545 pp</strong>',
                    'modal_price' => '<strong>Starting from:</strong> <strong>$6,545 per person</strong>',
                    'more_info_url' => '/packages/luxury-migration-big-five-safari-8-day/',
                    'modal_image_alt' => 'Luxury migration and Big Five safari',
                    'inquiry_subject' => '8-Day%20Luxury%20Migration%20%26%20Big%20Five%20Safari%20Inquiry',
                    'modal_points' => array(
                        'Premium northern circuit route with Tarangire, Serengeti and Ngorongoro highlights.',
                        'Northern Serengeti timing for migration action near Mara River crossing zones.',
                        'Luxury lodge stays across Elewana Tarangire Treetops, Kubu Kubu and more.',
                        'Private 4x4 with expert guide, park fees, airport transfers and full logistics included.',
                        'Ideal balance of iconic wildlife days and high-comfort accommodations.',
                    ),
                ),
                array(
                    'key' => 'tanzania-zanzibar-9d',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2026/01/zanzibar-1-1200x800.jpg',
                    'alt' => 'Tanzania and Zanzibar honeymoon journey',
                    'label' => 'June To July 2026',
                    'title' => '9-Day Tanzania & Zanzibar Honeymoon Journey',
                    'text' => 'Private safari in Tarangire and Manyara with a beach finale in Zanzibar for a special occasion.',
                    'price' => 'Starting from <strong>$3,580 pp</strong>',
                    'modal_price' => '<strong>Starting from:</strong> <strong>$3,580 per person</strong>',
                    'more_info_url' => '/packages/tanzania-zanzibar-honeymoon-9-day/',
                    'modal_image_alt' => 'Tanzania and Zanzibar private honeymoon journey',
                    'inquiry_subject' => '9-Day%20Tanzania%20%26%20Zanzibar%20Honeymoon%20Journey%20Inquiry',
                    'modal_points' => array(
                        'Private 9-day route for 2 travelers, ideal for honeymoon and special occasions.',
                        'Three full safari days in Tarangire plus Manyara highland lodge experience.',
                        'Internal flights included: Arusha to Zanzibar and Zanzibar to JRO.',
                        'Beach relaxation in Pwani Mchangani with half-board at Next Paradise Boutique Resort.',
                        'Professional guide, unlimited game drives, park fees and airport transfers included.',
                    ),
                ),
            ),
        ),
        'about' => array(
            'eyebrow' => 'Breeze Safaris',
            'title' => 'Travel Specialists Based in Tanzania',
            'text' => 'We are two safari specialists living in Tanzania, working with trusted local operators to design seamless journeys with genuine local depth.',
        ),
        'parks' => array(
            'head_kicker' => "Why You'll Love Tanzania",
            'head_title' => 'Parks That Turn Trips Into Stories',
            'intro' => 'Exceptional camps, iconic landscapes and unforgettable wildlife moments across Tanzania.',
            'slides' => array(
                array(
                    'slug' => 'serengeti-national-park',
                    'tag' => 'Serengeti',
                    'title' => 'Predator Kingdom',
                    'text' => "Vast plains, big cats and migration movement make Serengeti one of Africa's defining safari ecosystems.",
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2026/01/serengeti-4-1200x800.jpg',
                    'alt' => 'Serengeti wildlife plains',
                ),
                array(
                    'slug' => 'ngorongoro-conservation-area',
                    'tag' => 'Ngorongoro',
                    'title' => 'Crater Drama',
                    'text' => 'A dramatic caldera with dense wildlife sightings and one of the strongest single-day game drive experiences.',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/ngorongoro1-scaled-1200x800.jpg',
                    'alt' => 'Ngorongoro crater landscape',
                ),
                array(
                    'slug' => 'tarangire-national-park',
                    'tag' => 'Tarangire',
                    'title' => 'Baobab & Elephants',
                    'text' => 'Known for giant baobabs and elephant herds, Tarangire offers a relaxed pace and beautiful light.',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/tarangire-2-1200x800.jpg',
                    'alt' => 'Tarangire baobab landscape',
                ),
                array(
                    'slug' => 'lake-manyara-national-park',
                    'tag' => 'Lake Manyara',
                    'title' => 'Scenic Diversity',
                    'text' => 'Forest, lake edge and escarpment views create a compact park with excellent visual variety.',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/manyara-2-scaled-1200x800.jpg',
                    'alt' => 'Lake Manyara scenery',
                ),
                array(
                    'slug' => 'arusha-national-park',
                    'tag' => 'Arusha',
                    'title' => 'Soft Start Safari',
                    'text' => 'An ideal first stop near arrival for a smooth transition into longer northern circuit routes.',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Arusha-1-scaled-1200x800.jpg',
                    'alt' => 'Arusha national park safari view',
                ),
                array(
                    'slug' => 'ndutu-area',
                    'tag' => 'Ndutu',
                    'title' => 'Calving Season Action',
                    'text' => 'Powerful migration moments and predator behavior for travelers planning around key wildlife windows.',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Ndutu-1-scaled-1200x800.jpg',
                    'alt' => 'Ndutu migration plains',
                ),
                array(
                    'slug' => 'zanzibar',
                    'tag' => 'Zanzibar',
                    'title' => 'Beach Finale',
                    'text' => 'The perfect ending after safari days, with white sand, warm ocean water and curated coastal stays.',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2025/11/pexels-followalice-667205-1024x706.jpg',
                    'alt' => 'Zanzibar beach extension',
                ),
            ),
        ),
        'destinations' => array(
            'head_kicker' => 'National Parks & Beach',
            'head_title' => 'Explore Tanzania Destinations',
            'cards' => array(
                array(
                    'slug' => 'serengeti-national-park',
                    'title' => 'Serengeti National Park',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2026/01/serengeti-4-1200x800.jpg',
                    'alt' => 'Serengeti National Park safari',
                ),
                array(
                    'slug' => 'ngorongoro-conservation-area',
                    'title' => 'Ngorongoro Conservation Area',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/ngorongoro1-scaled-1200x800.jpg',
                    'alt' => 'Ngorongoro Conservation Area safari',
                ),
                array(
                    'slug' => 'tarangire-national-park',
                    'title' => 'Tarangire National Park',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/tarangire-2-1200x800.jpg',
                    'alt' => 'Tarangire National Park safari',
                ),
                array(
                    'slug' => 'lake-manyara-national-park',
                    'title' => 'Lake Manyara National Park',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/manyara-2-scaled-1200x800.jpg',
                    'alt' => 'Lake Manyara National Park safari',
                ),
                array(
                    'slug' => 'arusha-national-park',
                    'title' => 'Arusha National Park',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Arusha-1-scaled-1200x800.jpg',
                    'alt' => 'Arusha National Park safari',
                ),
                array(
                    'slug' => 'ndutu-area',
                    'title' => 'Ndutu Area',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Ndutu-1-scaled-1200x800.jpg',
                    'alt' => 'Ndutu Area safari',
                ),
                array(
                    'slug' => 'zanzibar',
                    'title' => 'Zanzibar',
                    'image' => 'https://breezesafaris.com/wp-content/uploads/2025/11/pexels-followalice-667205-1024x706.jpg',
                    'alt' => 'Zanzibar beach holiday',
                ),
            ),
        ),
        'footer' => array(
            'cta_kicker' => 'Breeze Safaris',
            'cta_title' => 'Your Tanzania Story Starts Here',
            'cta_button_text' => 'Start Planning',
            'cta_button_url' => 'mailto:info@breezesafaris.com?subject=Breeze%20Safaris%20Inquiry',
            'brand_text' => 'Tailor-made safaris designed by specialists based in Tanzania, with trusted local partners and private guiding.',
            'email' => 'info@breezesafaris.com',
            'phone' => '',
            'location' => 'Based in Tanzania',
            'extra_line' => 'Private Safari Planning',
            'copyright' => '© 2026 Breeze Safaris',
            'tagline' => 'Explore • Discover • Relax',
        ),
    );
}

function breeze_get_destination_defaults() {
    return array(
        'serengeti-national-park' => array(
            'title' => 'Serengeti National Park',
            'eyebrow' => 'Northern Tanzania Circuit',
            'hero_subtitle' => "Iconic open plains, high predator concentration and migration routes that create one of Africa's greatest safari experiences.",
            'hero_image' => 'https://breezesafaris.com/wp-content/uploads/2026/01/serengeti-4-2000x1333.jpg',
            'intro' => array(
                'Serengeti is the heartbeat of many Tanzania safari itineraries. Breeze Safaris designs each route around seasonality, preferred travel pace and accommodation style, so every game drive feels intentional rather than rushed.',
                'Whether you are chasing big cats, planning around migration movement, or combining northern parks with a Zanzibar extension, we build private journeys with trusted local partners and on-ground support.',
            ),
            'facts' => array(
                'Best for: Big cats, migration tracking, classic safari landscapes',
                'Ideal stay: 2 to 4 nights',
                'Pairs well with: Ngorongoro, Tarangire, Zanzibar',
                'Style: Private 4x4 game drives with expert local guides',
            ),
            'story_title' => 'Why Serengeti Feels Exceptional',
            'stories' => array(
                array(
                    'title' => 'Predator Action',
                    'text' => 'The Serengeti ecosystem consistently delivers excellent lion, cheetah and hyena encounters during well-planned game drives.',
                ),
                array(
                    'title' => 'Seasonal Routing',
                    'text' => 'Migration movement shifts throughout the year. We align your camps and drive areas with the strongest wildlife windows.',
                ),
                array(
                    'title' => 'Flexible Experience',
                    'text' => 'From authentic tented camps to premium lodges, your itinerary is tailored to budget, comfort preferences and travel rhythm.',
                ),
            ),
            'gallery_title' => 'Serengeti Gallery',
            'gallery' => array(
                array('class' => 'photo-xl', 'url' => 'https://breezesafaris.com/wp-content/uploads/2026/01/serengeti-4-2000x1333.jpg', 'alt' => 'Serengeti plains and wildlife view'),
                array('class' => 'photo-wide', 'url' => 'https://breezesafaris.com/wp-content/uploads/2026/01/serengeti-3-2000x1250.jpg', 'alt' => 'Serengeti game drive scenery'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2026/01/serengeti-5-2000x1196.jpg', 'alt' => 'Serengeti wildlife moment'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2026/01/serengeti-6-2000x1201.jpg', 'alt' => 'Serengeti safari photography'),
                array('class' => 'photo-sm', 'url' => 'https://breezesafaris.com/wp-content/uploads/2018/01/serengeti-scaled-2048x1536.jpg', 'alt' => 'Classic Serengeti landscape'),
            ),
            'cta_title' => 'Plan Your Serengeti Safari',
            'cta_text' => 'Tell us your dates, travel style and budget. We will shape the best Serengeti route for your trip.',
            'cta_button_text' => 'Inquire',
            'cta_button_url' => 'mailto:info@breezesafaris.com?subject=Serengeti%20Safari%20Inquiry',
        ),
        'ngorongoro-conservation-area' => array(
            'title' => 'Ngorongoro Conservation Area',
            'eyebrow' => 'Northern Tanzania Circuit',
            'hero_subtitle' => "A dramatic volcanic caldera with one of Africa's strongest single-day wildlife viewing experiences.",
            'hero_image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/ngorongoro1-scaled-2048x1366.jpg',
            'intro' => array(
                'Ngorongoro is one of the most iconic safari locations in East Africa. The crater floor concentrates wildlife in an extraordinary setting, making it a key highlight for travelers who want strong sightings with efficient routing.',
                'Breeze Safaris combines Ngorongoro with Serengeti, Tarangire and Lake Manyara to create well-paced itineraries that maximize time in the field while keeping logistics smooth.',
            ),
            'facts' => array(
                'Best for: Dense wildlife viewing and dramatic scenery',
                'Ideal stay: 1 to 2 nights',
                'Pairs well with: Serengeti and Tarangire',
                'Style: Private crater descent and full-day game drives',
            ),
            'story_title' => 'Why Travelers Love Ngorongoro',
            'stories' => array(
                array(
                    'title' => 'Crater Ecology',
                    'text' => 'A compact ecosystem where herbivores and predators can be observed in a single, high-impact game drive day.',
                ),
                array(
                    'title' => 'Visual Drama',
                    'text' => "Steep crater walls, open plains and seasonal lakes create one of Tanzania's most photogenic safari landscapes.",
                ),
                array(
                    'title' => 'Route Efficiency',
                    'text' => 'Ideal as a strategic stop between Serengeti and other northern parks, especially for shorter premium itineraries.',
                ),
            ),
            'gallery_title' => 'Ngorongoro Gallery',
            'gallery' => array(
                array('class' => 'photo-xl', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/ngorongoro1-scaled-2048x1366.jpg', 'alt' => 'Ngorongoro crater panoramic view'),
                array('class' => 'photo-wide', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/ngorongoro1-2000x1333.jpg', 'alt' => 'Ngorongoro wildlife landscape'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/ngorongoro1-scaled-1536x1024.jpg', 'alt' => 'Ngorongoro conservation area safari'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/ngorongoro1-1024x683.jpg', 'alt' => 'Game drive in Ngorongoro'),
                array('class' => 'photo-sm', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/ngorongoro1-950x320.jpg', 'alt' => 'Ngorongoro crater rim view'),
            ),
            'cta_title' => 'Design Your Ngorongoro Stop',
            'cta_text' => 'We will align your crater day with the rest of your Tanzania safari for better pace, stronger sightings and less transit stress.',
            'cta_button_text' => 'Inquire',
            'cta_button_url' => 'mailto:info@breezesafaris.com?subject=Ngorongoro%20Safari%20Inquiry',
        ),
        'tarangire-national-park' => array(
            'title' => 'Tarangire National Park',
            'eyebrow' => 'Northern Tanzania Circuit',
            'hero_subtitle' => 'A quieter safari atmosphere known for giant baobabs, sweeping views and large seasonal elephant concentrations.',
            'hero_image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/tarangire-2-scaled.jpg',
            'intro' => array(
                'Tarangire offers a distinct mood compared with other northern parks. It is spacious, scenic and ideal for travelers who enjoy slower-paced game viewing with fewer vehicles and rich photographic opportunities.',
                'Breeze Safaris often places Tarangire at the beginning of an itinerary, building momentum before moving into Ngorongoro and Serengeti for longer wildlife-focused circuits.',
            ),
            'facts' => array(
                'Best for: Elephant sightings, baobab scenery, calmer drives',
                'Ideal stay: 1 to 2 nights',
                'Pairs well with: Lake Manyara, Ngorongoro, Serengeti',
                'Style: Private drives with flexible timing',
            ),
            'story_title' => 'Why Tarangire Works So Well',
            'stories' => array(
                array(
                    'title' => 'Elephant Territory',
                    'text' => "Tarangire is one of Tanzania's standout parks for elephant encounters, especially in dry-season periods.",
                ),
                array(
                    'title' => 'Landscape Character',
                    'text' => 'Ancient baobabs, river channels and open woodlands create visual depth that feels different from open Serengeti plains.',
                ),
                array(
                    'title' => 'Pacing Advantage',
                    'text' => 'Its location and rhythm make Tarangire excellent for balancing travel flow in tailor-made northern itineraries.',
                ),
            ),
            'gallery_title' => 'Tarangire Gallery',
            'gallery' => array(
                array('class' => 'photo-xl', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/tarangire-2-scaled.jpg', 'alt' => 'Tarangire landscape with baobab trees'),
                array('class' => 'photo-wide', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/tarangire-2-2000x1723.jpg', 'alt' => 'Tarangire wildlife in golden light'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/tarangire-2-1200x800.jpg', 'alt' => 'Tarangire National Park game drive'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/tarangire-2-1024x882.jpg', 'alt' => 'Tarangire National Park safari view'),
                array('class' => 'photo-sm', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/tarangire-2-950x320.jpg', 'alt' => 'Wide Tarangire panorama'),
            ),
            'cta_title' => 'Build Your Tarangire Itinerary',
            'cta_text' => 'We can combine Tarangire with the right park sequence for your preferred trip length and wildlife priorities.',
            'cta_button_text' => 'Inquire',
            'cta_button_url' => 'mailto:info@breezesafaris.com?subject=Tarangire%20Safari%20Inquiry',
        ),
        'lake-manyara-national-park' => array(
            'title' => 'Lake Manyara National Park',
            'eyebrow' => 'Northern Tanzania Circuit',
            'hero_subtitle' => 'A compact but visually rich park with forest, lake-edge wildlife and dramatic Rift Valley escarpment scenery.',
            'hero_image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/manyara-2-scaled-2048x1366.jpg',
            'intro' => array(
                'Lake Manyara is an excellent contrast point inside a northern Tanzania safari itinerary. The transition between forest zones, open areas and lake landscapes creates a distinct drive experience compared with larger parks.',
                'Breeze Safaris uses Manyara strategically for smooth routing, balanced wildlife variety and strong scenery before or after longer Serengeti segments.',
            ),
            'facts' => array(
                'Best for: Scenic diversity and short, high-value game drives',
                'Ideal stay: 1 night or full-day visit',
                'Pairs well with: Tarangire and Ngorongoro',
                'Style: Flexible private drives for mixed wildlife interests',
            ),
            'story_title' => 'What Makes Manyara Different',
            'stories' => array(
                array(
                    'title' => 'Habitat Variety',
                    'text' => 'From groundwater forest to open terrain and lake edge, Manyara offers visual and ecological diversity in a compact area.',
                ),
                array(
                    'title' => 'Great Transition Park',
                    'text' => 'Manyara fits naturally into northern circuits and helps optimize drive times between major safari zones.',
                ),
                array(
                    'title' => 'Photography Value',
                    'text' => 'Changing light and varied backdrops create strong opportunities for wildlife and landscape photography.',
                ),
            ),
            'gallery_title' => 'Lake Manyara Gallery',
            'gallery' => array(
                array('class' => 'photo-xl', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/manyara-2-scaled-2048x1366.jpg', 'alt' => 'Lake Manyara scenic wildlife view'),
                array('class' => 'photo-wide', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/manyara-2-2000x1334.jpg', 'alt' => 'Lake Manyara safari scenery'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/manyara-2-scaled-1536x1024.jpg', 'alt' => 'Lake Manyara National Park landscape'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/manyara-2-1024x683.jpg', 'alt' => 'Game drive in Lake Manyara'),
                array('class' => 'photo-sm', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/manyara-2-950x320.jpg', 'alt' => 'Lake Manyara panoramic view'),
            ),
            'cta_title' => 'Include Lake Manyara In Your Route',
            'cta_text' => 'We will position Manyara at the right point in your journey to add scenic variety and keep your safari pacing comfortable.',
            'cta_button_text' => 'Inquire',
            'cta_button_url' => 'mailto:info@breezesafaris.com?subject=Lake%20Manyara%20Safari%20Inquiry',
        ),
        'arusha-national-park' => array(
            'title' => 'Arusha National Park',
            'eyebrow' => 'Northern Tanzania Circuit',
            'hero_subtitle' => 'A beautiful soft-start safari park near Arusha, ideal for first wildlife encounters before deeper northern circuits.',
            'hero_image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Arusha-1-scaled-2048x1366.jpg',
            'intro' => array(
                'Arusha National Park is often overlooked, but it is an excellent beginning for travelers arriving in northern Tanzania. Its location makes it practical, while its scenery offers a calm and photogenic introduction to safari life.',
                'Breeze Safaris can include Arusha as a first-day game drive, helping you transition comfortably into longer wildlife routes across Tarangire, Ngorongoro and Serengeti.',
            ),
            'facts' => array(
                'Best for: Arrival-day safari and scenic variety',
                'Ideal stay: 1 day or 1 night',
                'Pairs well with: Tarangire and full northern circuit',
                'Style: Soft-start private drives with flexible timing',
            ),
            'story_title' => 'Why Add Arusha National Park',
            'stories' => array(
                array(
                    'title' => 'Excellent First Day',
                    'text' => 'Close proximity to Arusha allows for meaningful game viewing without long transit stress after flights.',
                ),
                array(
                    'title' => 'Visual Contrast',
                    'text' => 'Forest zones and open viewpoints bring a different atmosphere that complements later big-park experiences.',
                ),
                array(
                    'title' => 'Smart Route Design',
                    'text' => 'Works well as the opening chapter of a tailor-made itinerary before heading west into larger reserves.',
                ),
            ),
            'gallery_title' => 'Arusha Park Gallery',
            'gallery' => array(
                array('class' => 'photo-xl', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Arusha-1-scaled-2048x1366.jpg', 'alt' => 'Arusha National Park scenic safari'),
                array('class' => 'photo-wide', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Arusha-1-2000x1333.jpg', 'alt' => 'Arusha park landscape and wildlife'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Arusha-1-scaled-1536x1024.jpg', 'alt' => 'Arusha National Park game drive'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Arusha-1-1024x683.jpg', 'alt' => 'Arusha wildlife encounter'),
                array('class' => 'photo-sm', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Arusha-1-950x320.jpg', 'alt' => 'Arusha panoramic scenery'),
            ),
            'cta_title' => 'Start Your Safari Smoothly',
            'cta_text' => 'We can include Arusha National Park as the perfect first chapter in your custom Tanzania route.',
            'cta_button_text' => 'Inquire',
            'cta_button_url' => 'mailto:info@breezesafaris.com?subject=Arusha%20National%20Park%20Inquiry',
        ),
        'ndutu-area' => array(
            'title' => 'Ndutu Area',
            'eyebrow' => 'Southern Serengeti Ecosystem',
            'hero_subtitle' => "One of Tanzania's key seasonal safari regions for migration calving activity and intense predator behavior.",
            'hero_image' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Ndutu-1-scaled-2048x1366.jpg',
            'intro' => array(
                'Ndutu is all about timing. During the migration calving window, wildlife concentration can be extraordinary, making this one of the most dynamic safari locations for travelers focused on behavior, movement and photography.',
                'Breeze Safaris plans Ndutu around season, camp positioning and route flow, so your trip aligns with the strongest opportunities on the ground.',
            ),
            'facts' => array(
                'Best for: Migration calving season and predator activity',
                'Ideal stay: 2 to 3 nights in season',
                'Pairs well with: Serengeti and Ngorongoro',
                'Style: Seasonal private guiding with focused game drives',
            ),
            'story_title' => 'Why Ndutu Is Special',
            'stories' => array(
                array(
                    'title' => 'Calving Window',
                    'text' => 'When timed correctly, Ndutu offers unforgettable scenes tied to wildebeest births and predator responses.',
                ),
                array(
                    'title' => 'Action & Storytelling',
                    'text' => 'Rapid behavior changes and dynamic wildlife interactions make Ndutu a favorite for keen safari travelers.',
                ),
                array(
                    'title' => 'Route Integration',
                    'text' => 'Ndutu works best as part of a broader tailored circuit that includes Serengeti sectors and Ngorongoro access.',
                ),
            ),
            'gallery_title' => 'Ndutu Gallery',
            'gallery' => array(
                array('class' => 'photo-xl', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Ndutu-1-scaled-2048x1366.jpg', 'alt' => 'Ndutu migration season scenery'),
                array('class' => 'photo-wide', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Ndutu-1-2000x1334.jpg', 'alt' => 'Ndutu safari game drive landscape'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Ndutu-1-scaled-1536x1024.jpg', 'alt' => 'Ndutu wildlife photography'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Ndutu-1-1024x683.jpg', 'alt' => 'Ndutu plains and wildlife'),
                array('class' => 'photo-sm', 'url' => 'https://breezesafaris.com/wp-content/uploads/2017/09/Ndutu-1-950x320.jpg', 'alt' => 'Ndutu panoramic view'),
            ),
            'cta_title' => 'Time Your Ndutu Safari Right',
            'cta_text' => 'Share your travel window and we will design the strongest migration-focused Ndutu route for your trip.',
            'cta_button_text' => 'Inquire',
            'cta_button_url' => 'mailto:info@breezesafaris.com?subject=Ndutu%20Safari%20Inquiry',
        ),
        'zanzibar' => array(
            'title' => 'Zanzibar Extension',
            'eyebrow' => 'Safari + Beach Combination',
            'hero_subtitle' => 'Finish your Tanzania safari with curated Indian Ocean downtime in Zanzibar, planned to match your preferred pace and style.',
            'hero_image' => 'https://breezesafaris.com/wp-content/uploads/2025/11/pexels-followalice-667205-2000x1379.jpg',
            'intro' => array(
                'After intense safari days, Zanzibar is the ideal transition into rest, sea breeze and coastal comfort. Breeze Safaris arranges smooth domestic links from bush destinations to island stays with no unnecessary friction.',
                'From boutique hideaways to luxury beach resorts, we tailor your Zanzibar leg around trip length, budget and the atmosphere you want after the safari chapter.',
            ),
            'facts' => array(
                'Best for: Post-safari relaxation and celebration trips',
                'Ideal stay: 3 to 5 nights',
                'Pairs well with: Serengeti, Ngorongoro, Tarangire circuits',
                'Style: End-to-end safari + beach itinerary coordination',
            ),
            'story_title' => 'Why Add Zanzibar',
            'stories' => array(
                array(
                    'title' => 'Perfect Contrast',
                    'text' => 'Wildlife intensity followed by beach calm creates a complete and balanced Tanzania travel experience.',
                ),
                array(
                    'title' => 'Curated Stays',
                    'text' => 'We match property style to your travel profile, from intimate boutique options to premium oceanfront resorts.',
                ),
                array(
                    'title' => 'Seamless Logistics',
                    'text' => 'Flight timing and transfer coordination are built into your itinerary so the bush-to-beach transition stays smooth.',
                ),
            ),
            'gallery_title' => 'Zanzibar Gallery',
            'gallery' => array(
                array('class' => 'photo-xl', 'url' => 'https://breezesafaris.com/wp-content/uploads/2025/11/pexels-followalice-667205-2000x1379.jpg', 'alt' => 'Zanzibar beach view'),
                array('class' => 'photo-wide', 'url' => 'https://breezesafaris.com/wp-content/uploads/2025/11/IMG_7208-1-2000x1333.png', 'alt' => 'Luxury stay atmosphere for Zanzibar extension'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2025/11/MTC-tented-suite2.webp', 'alt' => 'Premium accommodation example'),
                array('class' => 'photo-mid', 'url' => 'https://breezesafaris.com/wp-content/uploads/2025/11/IMG_7903.jpg', 'alt' => 'Safari and beach lifestyle moment'),
                array('class' => 'photo-sm', 'url' => 'https://breezesafaris.com/wp-content/uploads/2026/02/image-2-edited.jpg', 'alt' => 'Zanzibar holiday detail'),
            ),
            'cta_title' => 'Add Zanzibar To Your Safari',
            'cta_text' => 'Tell us your preferred number of beach days and we will design a seamless Tanzania + Zanzibar combination.',
            'cta_button_text' => 'Inquire',
            'cta_button_url' => 'mailto:info@breezesafaris.com?subject=Zanzibar%20Extension%20Inquiry',
        ),
    );
}

function breeze_get_destination_default($slug) {
    $all = breeze_get_destination_defaults();

    if (isset($all[$slug])) {
        return $all[$slug];
    }

    return array(
        'title' => '',
        'eyebrow' => 'Tanzania Destination',
        'hero_subtitle' => '',
        'hero_image' => '',
        'intro' => array(),
        'facts' => array(),
        'story_title' => 'Highlights',
        'stories' => array(),
        'gallery_title' => 'Gallery',
        'gallery' => array(),
        'cta_title' => '',
        'cta_text' => '',
        'cta_button_text' => 'Inquire',
        'cta_button_url' => 'mailto:info@breezesafaris.com',
    );
}

function breeze_get_privacy_policy_default_content() {
    return <<<HTML
<p><strong>Last updated: February 2026</strong></p>
<p>Breeze Safaris is committed to protecting your personal data and respecting your privacy. This Privacy Policy explains how we collect, use, process and safeguard your information when you visit <a href="https://breezesafaris.com">https://breezesafaris.com</a> or contact us regarding our services.</p>
<h2>1. Who We Are</h2>
<p>Our website address is: <a href="https://breezesafaris.com">https://breezesafaris.com</a>.</p>
<h2>2. Data Controller</h2>
<p>For the purposes of the General Data Protection Regulation, GDPR, Breeze Safaris acts as the Data Controller in relation to personal data collected through this website.</p>
<p>Brand name: Breeze Safaris<br>Website: <a href="https://breezesafaris.com">https://breezesafaris.com</a><br>Contact email: <a href="mailto:info@breezesafaris.com">info@breezesafaris.com</a></p>
<p>If you have any questions regarding this Privacy Policy or your personal data, please contact us using the email above.</p>
<h2>3. Our Business Model</h2>
<p>Breeze Safaris is not a licensed tour operator. We act as an intermediary between clients and licensed local tour operators in Tanzania.</p>
<p>We design tailor made safari itineraries and connect clients with carefully selected local partners who execute the travel services. Once a booking is confirmed, certain personal data may be shared with the relevant local operator strictly for the purpose of delivering the travel services.</p>
<h2>4. Personal Data We Collect</h2>
<p>We may collect and process the following personal data:</p>
<ul>
<li>Full name</li>
<li>Email address</li>
<li>Telephone number</li>
<li>Country of residence</li>
<li>Travel preferences and itinerary requirements</li>
<li>Passport information when required for bookings</li>
<li>Any additional information voluntarily provided through contact forms or email communication</li>
</ul>
<p>We may also collect technical data automatically, including:</p>
<ul>
<li>IP address</li>
<li>Browser type and version</li>
<li>Device type</li>
<li>Pages visited</li>
<li>Date and time of access</li>
</ul>
<h2>5. Legal Basis for Processing</h2>
<p>We process your personal data based on one or more of the following legal grounds:</p>
<ul>
<li>Your consent when submitting a contact form</li>
<li>Pre contractual steps taken at your request</li>
<li>Performance of a contract once a booking is confirmed</li>
<li>Compliance with legal obligations</li>
<li>Legitimate interests in operating and improving our services</li>
</ul>
<h2>6. Purpose of Processing</h2>
<p>Your personal data is processed for the following purposes:</p>
<ul>
<li>Responding to enquiries</li>
<li>Preparing customised safari proposals</li>
<li>Coordinating bookings with local tour operators</li>
<li>Communicating important travel information</li>
<li>Improving website performance and user experience</li>
<li>Marketing activities where consent has been provided</li>
</ul>
<p>We do not sell, rent or trade your personal data.</p>
<h2>7. Data Sharing and Third Parties</h2>
<p>Your personal data may be shared with:</p>
<ul>
<li>Licensed local tour operators in Tanzania responsible for delivering the travel services</li>
<li>Accommodation providers and service suppliers relevant to your itinerary</li>
<li>Website hosting providers</li>
<li>Email service providers</li>
<li>Marketing and analytics providers such as Google Analytics, Google Ads and Meta Ads</li>
<li>Legal or regulatory authorities when required by law</li>
</ul>
<p>Local tour operators receiving your data may act as independent Data Controllers under applicable laws in their jurisdiction.</p>
<p>We ensure that data is shared only when necessary and proportionate to deliver the requested services.</p>
<h2>8. International Data Transfers</h2>
<p>As we work with partners based in Tanzania, your personal data may be transferred outside the European Economic Area.</p>
<p>When such transfers occur, we take reasonable steps to ensure appropriate safeguards are in place to protect your data in accordance with GDPR requirements.</p>
<p>By requesting our services, you acknowledge that such international transfers may be necessary for the performance of your travel arrangements.</p>
<h2>9. Data Retention</h2>
<p>We retain personal data only for as long as necessary to:</p>
<ul>
<li>Fulfil the purposes outlined in this Policy</li>
<li>Comply with legal, tax and accounting obligations</li>
<li>Resolve disputes</li>
</ul>
<p>When data is no longer required, it will be securely deleted or anonymised.</p>
<h2>10. Your Rights Under GDPR</h2>
<p>If you are located in the European Union or United Kingdom, you have the right to:</p>
<ul>
<li>Access your personal data</li>
<li>Request correction of inaccurate data</li>
<li>Request erasure of your data</li>
<li>Request restriction of processing</li>
<li>Object to processing</li>
<li>Request data portability</li>
<li>Withdraw consent at any time</li>
</ul>
<p>To exercise any of these rights, please contact us at <a href="mailto:info@breezesafaris.com">info@breezesafaris.com</a>.</p>
<p>You also have the right to lodge a complaint with your local data protection supervisory authority.</p>
<h2>11. Cookies and Tracking Technologies</h2>
<p>Our website may use cookies and similar technologies to:</p>
<ul>
<li>Analyse website traffic</li>
<li>Improve user experience</li>
<li>Deliver relevant advertising</li>
</ul>
<p>You may control or disable cookies through your browser settings. A cookie consent banner may appear when you first visit our website.</p>
<h2>12. Data Security</h2>
<p>We implement appropriate technical and organisational measures to protect personal data against unauthorised access, alteration, disclosure or destruction.</p>
<p>However, no method of transmission over the internet is completely secure and we cannot guarantee absolute security.</p>
<h2>13. Changes to This Policy</h2>
<p>We reserve the right to update this Privacy Policy at any time. Any changes will be published on this page with an updated revision date.</p>
<p>We encourage users to review this Policy periodically.</p>
<h2>14. Exercising Your Data Rights</h2>
<p>To exercise any of your rights under applicable data protection laws, including access, rectification, restriction, objection or erasure of your personal data, please contact:</p>
<p><strong><a href="mailto:info@breezesafaris.com">info@breezesafaris.com</a></strong></p>
<p>We may request proof of identity to ensure data security. All valid requests will be handled within the timeframes required under GDPR.</p>
HTML;
}

function breeze_build_intro_content($paragraphs) {
    if (!is_array($paragraphs) || empty($paragraphs)) {
        return '';
    }

    $html = '';
    foreach ($paragraphs as $paragraph) {
        $text = trim((string) $paragraph);
        if ($text === '') {
            continue;
        }
        $html .= '<p>' . esc_html($text) . '</p>' . "\n";
    }

    return trim($html);
}

function breeze_get_home_default_content() {
    $defaults = breeze_get_home_defaults();
    $hero = $defaults['hero'];
    $packages = $defaults['packages']['cards'];
    $parks = $defaults['parks']['slides'];

    ob_start();
    ?>
<main>
  <section class="hero" id="hero">
    <video autoplay muted loop playsinline preload="auto" class="hero-video">
      <source src="<?php echo esc_url($hero['video_url']); ?>" type="video/mp4">
    </video>
    <div class="hero-overlay"></div>
    <div class="hero-content">
      <p class="hero-kicker"><?php echo esc_html($hero['kicker']); ?></p>
      <h1><?php echo esc_html($hero['title']); ?></h1>
      <p class="hero-sub"><?php echo wp_kses_post($hero['subtitle']); ?></p>
      <a href="<?php echo esc_url($hero['button_url']); ?>" class="btn"><?php echo esc_html($hero['button_text']); ?></a>
    </div>
  </section>

  <section class="packages" id="packages">
    <div class="section-head">
      <p><?php echo esc_html($defaults['packages']['head_kicker']); ?></p>
      <h2><?php echo esc_html($defaults['packages']['head_title']); ?></h2>
      <div class="section-cta">
        <a class="modal-btn modal-btn-secondary" href="<?php echo esc_url(home_url('/packages/')); ?>">View All Packages</a>
      </div>
    </div>
    <div class="packages-controls">
      <button type="button" class="packages-arrow" id="packagesPrev" aria-label="Previous packages">‹</button>
      <button type="button" class="packages-arrow" id="packagesNext" aria-label="Next packages">›</button>
    </div>
    <div class="cards packages-carousel" id="packagesCarousel">
      <?php foreach ($packages as $card) : ?>
        <article class="card interactive-card" role="button" tabindex="0" data-package="<?php echo esc_attr($card['key']); ?>" aria-label="<?php echo esc_attr('Open ' . $card['title'] . ' details'); ?>">
          <img src="<?php echo esc_url($card['image']); ?>" alt="<?php echo esc_attr($card['alt']); ?>">
          <div class="card-content">
            <p class="card-label"><?php echo esc_html($card['label']); ?></p>
            <h3><?php echo esc_html($card['title']); ?></h3>
            <p><?php echo esc_html($card['text']); ?></p>
            <?php if (!empty($card['price'])) : ?>
              <p class="card-price"><?php echo wp_kses_post($card['price']); ?></p>
            <?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
    <div class="packages-dots" id="packagesDots" aria-label="Packages slider navigation">
      <?php foreach ($packages as $index => $card) : ?>
        <button type="button" class="dot <?php echo $index === 0 ? 'is-active' : ''; ?>" data-index="<?php echo esc_attr((string) $index); ?>" aria-label="<?php echo esc_attr('Go to package ' . ($index + 1)); ?>"></button>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="parks-showcase" id="parks-showcase">
    <div class="parks-head section-head">
      <div>
        <p><?php echo esc_html($defaults['parks']['head_kicker']); ?></p>
        <h2><?php echo esc_html($defaults['parks']['head_title']); ?></h2>
        <p class="parks-intro"><?php echo esc_html($defaults['parks']['intro']); ?></p>
        <div class="parks-dots" id="parksDots" aria-label="Parks slider navigation">
          <?php foreach ($parks as $index => $park) : ?>
            <button type="button" class="dot <?php echo $index === 0 ? 'is-active' : ''; ?>" data-index="<?php echo esc_attr((string) $index); ?>" aria-label="<?php echo esc_attr('Go to slide ' . ($index + 1)); ?>"></button>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="parks-controls">
        <button type="button" class="parks-arrow" id="parksPrev" aria-label="Previous parks">‹</button>
        <button type="button" class="parks-arrow" id="parksNext" aria-label="Next parks">›</button>
      </div>
    </div>
    <div class="parks-carousel-wrap">
      <div class="parks-carousel" id="parksCarousel">
        <?php foreach ($parks as $park) : ?>
          <article class="park-slide">
            <img src="<?php echo esc_url($park['image']); ?>" alt="<?php echo esc_attr($park['alt']); ?>">
            <div class="park-slide-content">
              <p class="park-tag"><?php echo esc_html($park['tag']); ?></p>
              <h3><?php echo esc_html($park['title']); ?></h3>
              <p><?php echo esc_html($park['text']); ?></p>
              <a href="<?php echo esc_url(home_url('/' . $park['slug'] . '/')); ?>">Explore Park</a>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

</main>

<div class="modal-overlay" id="packageModal" aria-hidden="true">
  <div class="modal-panel" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
    <button class="modal-close" id="modalClose" aria-label="Close details">×</button>
    <div id="modalContent"></div>
  </div>
</div>

<?php foreach ($packages as $card) : ?>
<template id="tpl-<?php echo esc_attr($card['key']); ?>">
  <div class="modal-grid">
    <img src="<?php echo esc_url($card['image']); ?>" alt="<?php echo esc_attr(isset($card['modal_image_alt']) ? $card['modal_image_alt'] : $card['title']); ?>">
    <div class="modal-copy">
      <p class="modal-kicker"><?php echo esc_html($card['label']); ?></p>
      <h3 id="modalTitle"><?php echo esc_html($card['title']); ?></h3>
      <ul>
        <?php foreach ($card['modal_points'] as $point) : ?>
          <li><?php echo esc_html($point); ?></li>
        <?php endforeach; ?>
      </ul>
      <?php if (!empty($card['modal_price'])) : ?>
        <p class="modal-price"><?php echo wp_kses_post($card['modal_price']); ?></p>
      <?php endif; ?>
      <div class="modal-actions">
        <a class="modal-btn" href="<?php echo esc_url('mailto:info@breezesafaris.com?subject=' . $card['inquiry_subject']); ?>">Inquire</a>
        <?php if (!empty($card['more_info_url'])) : ?>
          <a class="modal-btn modal-btn-secondary" href="<?php echo esc_url($card['more_info_url']); ?>">More Info</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</template>
<?php endforeach; ?>
    <?php

    return trim((string) ob_get_clean());
}

function breeze_get_destination_default_content($slug) {
    $data = breeze_get_destination_default($slug);
    if (empty($data['title'])) {
        return '';
    }

    $intro = isset($data['intro']) && is_array($data['intro']) ? $data['intro'] : array();
    $facts = isset($data['facts']) && is_array($data['facts']) ? $data['facts'] : array();
    $stories = isset($data['stories']) && is_array($data['stories']) ? $data['stories'] : array();
    $gallery = isset($data['gallery']) && is_array($data['gallery']) ? $data['gallery'] : array();

    ob_start();
    ?>
<main class="destination-main">
  <section class="destination-hero" id="hero" style="background-image:url('<?php echo esc_url($data['hero_image']); ?>')">
    <div class="destination-hero-inner">
      <p class="destination-eyebrow"><?php echo esc_html($data['eyebrow']); ?></p>
      <h1><?php echo esc_html($data['title']); ?></h1>
      <p><?php echo esc_html($data['hero_subtitle']); ?></p>
    </div>
  </section>

  <section class="destination-intro section-shell">
    <div class="intro-copy">
      <?php foreach ($intro as $paragraph) : ?>
        <p><?php echo esc_html($paragraph); ?></p>
      <?php endforeach; ?>
    </div>
    <?php if (!empty($facts)) : ?>
      <aside class="facts-card">
        <h2>At a Glance</h2>
        <ul>
          <?php foreach ($facts as $fact) : ?>
            <li><?php echo esc_html($fact); ?></li>
          <?php endforeach; ?>
        </ul>
      </aside>
    <?php endif; ?>
  </section>

  <?php if (!empty($stories)) : ?>
    <section class="section-shell">
      <h2 class="section-title"><?php echo esc_html($data['story_title']); ?></h2>
      <div class="story-grid">
        <?php foreach ($stories as $story) : ?>
          <article class="story-card">
            <h3><?php echo esc_html($story['title']); ?></h3>
            <p><?php echo esc_html($story['text']); ?></p>
          </article>
        <?php endforeach; ?>
      </div>
    </section>
  <?php endif; ?>

  <?php if (!empty($gallery)) : ?>
    <section class="section-shell">
      <h2 class="section-title"><?php echo esc_html($data['gallery_title']); ?></h2>
      <div class="photo-grid">
        <?php foreach ($gallery as $photo) : ?>
          <figure class="<?php echo esc_attr($photo['class']); ?>"><img src="<?php echo esc_url($photo['url']); ?>" alt="<?php echo esc_attr($photo['alt']); ?>"></figure>
        <?php endforeach; ?>
      </div>
    </section>
  <?php endif; ?>

  <section class="section-shell">
    <div class="cta-band">
      <div>
        <h2><?php echo esc_html($data['cta_title']); ?></h2>
        <p><?php echo esc_html($data['cta_text']); ?></p>
      </div>
      <a href="<?php echo esc_url($data['cta_button_url']); ?>"><?php echo esc_html($data['cta_button_text']); ?></a>
    </div>
  </section>
</main>
    <?php

    return trim((string) ob_get_clean());
}

function breeze_get_seed_page_definitions() {
    $pages = array(
        array(
            'title'    => 'Home',
            'slug'     => 'home',
            'content'  => breeze_get_home_default_content(),
            'template' => 'default',
        ),
        array(
            'title'    => 'Privacy Policy',
            'slug'     => 'privacy-policy',
            'content'  => breeze_get_privacy_policy_default_content(),
            'template' => 'default',
        ),
    );

    foreach (breeze_get_destination_defaults() as $slug => $defaults) {
        $pages[] = array(
            'title'    => $defaults['title'],
            'slug'     => $slug,
            'content'  => breeze_get_destination_default_content($slug),
            'template' => 'page-templates/destination-page.php',
        );
    }

    return $pages;
}
