<?php
$logo_url = breeze_get_logo_url();
$header_classes = array('site-header');
$is_destination_template = is_page_template('page-templates/destination-page.php');
if (!is_front_page() && !$is_destination_template) {
    $header_classes[] = 'is-solid';
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
  <header class="<?php echo esc_attr(implode(' ', $header_classes)); ?>" id="siteHeader">
    <a class="brand" href="<?php echo esc_url(home_url('/')); ?>">
      <img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?> logo">
    </a>
    <button class="nav-toggle" id="navToggle" type="button" aria-label="<?php esc_attr_e('Open navigation menu', 'breeze-codex-theme'); ?>" aria-expanded="false" aria-controls="siteNav">
      <span></span>
      <span></span>
      <span></span>
    </button>
    <nav id="siteNav" class="site-nav">
      <?php
      if (has_nav_menu('primary')) {
          wp_nav_menu(
              array(
                  'theme_location' => 'primary',
                  'container'      => false,
                  'items_wrap'     => '%3$s',
                  'walker'         => new Breeze_Flat_Nav_Walker(),
                  'fallback_cb'    => false,
              )
          );
      } else {
          breeze_render_menu_links(breeze_primary_fallback_links());
      }
      ?>
    </nav>
  </header>
