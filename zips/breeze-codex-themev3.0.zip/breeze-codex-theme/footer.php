<?php
$home_defaults = breeze_get_home_defaults();
$footer_defaults = $home_defaults['footer'];

$cta_kicker = get_theme_mod('breeze_footer_cta_kicker', $footer_defaults['cta_kicker']);
$cta_title = get_theme_mod('breeze_footer_cta_title', $footer_defaults['cta_title']);
$cta_button_text = get_theme_mod('breeze_footer_cta_button_text', $footer_defaults['cta_button_text']);
$cta_button_url = get_theme_mod('breeze_footer_cta_button_url', $footer_defaults['cta_button_url']);
$brand_text = get_theme_mod('breeze_footer_brand_text', $footer_defaults['brand_text']);
$email = get_theme_mod('breeze_footer_email', $footer_defaults['email']);
$phone = get_theme_mod('breeze_footer_phone', $footer_defaults['phone']);
$location = get_theme_mod('breeze_footer_location', $footer_defaults['location']);
$extra_line = get_theme_mod('breeze_footer_extra_line', $footer_defaults['extra_line']);
$copyright = get_theme_mod('breeze_footer_copyright', $footer_defaults['copyright']);
$tagline = get_theme_mod('breeze_footer_tagline', $footer_defaults['tagline']);
?>
  <footer class="site-footer" id="contact">
    <div class="footer-shell">
      <div class="footer-hero">
        <div>
          <p class="footer-kicker"><?php echo esc_html($cta_kicker); ?></p>
          <h2><?php echo esc_html($cta_title); ?></h2>
        </div>
        <a class="footer-cta" href="<?php echo esc_url($cta_button_url); ?>"><?php echo esc_html($cta_button_text); ?></a>
      </div>
      <div class="footer-grid">
        <div class="footer-col">
          <h3><?php bloginfo('name'); ?></h3>
          <p><?php echo esc_html($brand_text); ?></p>
        </div>
        <div class="footer-col">
          <h3><?php esc_html_e('Explore', 'breeze-codex-theme'); ?></h3>
          <?php
          if (has_nav_menu('footer_explore')) {
              wp_nav_menu(
                  array(
                      'theme_location' => 'footer_explore',
                      'container'      => false,
                      'items_wrap'     => '%3$s',
                      'walker'         => new Breeze_Flat_Nav_Walker(),
                      'fallback_cb'    => false,
                  )
              );
          } else {
              breeze_render_menu_links(breeze_footer_explore_fallback_links());
          }
          ?>
        </div>
        <div class="footer-col">
          <h3><?php esc_html_e('Top Destinations', 'breeze-codex-theme'); ?></h3>
          <?php
          if (has_nav_menu('footer_destinations')) {
              wp_nav_menu(
                  array(
                      'theme_location' => 'footer_destinations',
                      'container'      => false,
                      'items_wrap'     => '%3$s',
                      'walker'         => new Breeze_Flat_Nav_Walker(),
                      'fallback_cb'    => false,
                  )
              );
          } else {
              breeze_render_menu_links(breeze_footer_destinations_fallback_links());
          }
          ?>
        </div>
        <div class="footer-col">
          <h3><?php esc_html_e('Contact', 'breeze-codex-theme'); ?></h3>
          <?php if (!empty($email)) : ?>
            <a href="<?php echo esc_url('mailto:' . sanitize_email($email)); ?>"><?php echo esc_html($email); ?></a>
          <?php endif; ?>
          <?php if (!empty($phone)) : ?>
            <a href="<?php echo esc_url('tel:' . preg_replace('/[^0-9\+]/', '', $phone)); ?>"><?php echo esc_html($phone); ?></a>
          <?php endif; ?>
          <?php if (!empty($location)) : ?>
            <p><?php echo esc_html($location); ?></p>
          <?php endif; ?>
          <?php if (!empty($extra_line)) : ?>
            <p><?php echo esc_html($extra_line); ?></p>
          <?php endif; ?>
        </div>
      </div>
      <div class="footer-bottom">
        <p><?php echo esc_html($copyright); ?></p>
        <p><?php echo esc_html($tagline); ?></p>
      </div>
    </div>
  </footer>
<?php wp_footer(); ?>
</body>
</html>
