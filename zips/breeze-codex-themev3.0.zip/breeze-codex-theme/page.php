<?php
get_header();
?>

<main class="privacy-main">
  <?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
      <?php $page_content = trim((string) get_the_content()); ?>
      <?php $content_has_h1 = stripos($page_content, '<h1') !== false; ?>
      <section class="privacy-shell">
        <?php if (get_post_field('post_name', get_the_ID()) === 'privacy-policy') : ?>
          <p class="privacy-kicker"><?php esc_html_e('Legal', 'breeze-codex-theme'); ?></p>
        <?php endif; ?>
        <?php if (!$content_has_h1) : ?>
          <h1><?php the_title(); ?></h1>
        <?php endif; ?>
        <div class="entry-content">
          <?php if ($page_content !== '') : ?>
            <?php the_content(); ?>
          <?php endif; ?>
        </div>
      </section>
    <?php endwhile; ?>
  <?php endif; ?>
</main>

<?php
get_footer();
