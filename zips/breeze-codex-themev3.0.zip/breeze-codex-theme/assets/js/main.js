const header = document.getElementById("siteHeader");
const hero = document.getElementById("hero");
const navToggle = document.getElementById("navToggle");
const siteNav = document.getElementById("siteNav");

if (header && hero) {
  const syncHeaderOnScroll = () => {
    header.classList.toggle("is-solid", window.scrollY > 0);
  };

  window.addEventListener("scroll", syncHeaderOnScroll, { passive: true });
  syncHeaderOnScroll();
}

function closeMobileMenu() {
  if (!header || !navToggle) return;
  header.classList.remove("is-menu-open");
  navToggle.setAttribute("aria-expanded", "false");
}

if (navToggle && header && siteNav) {
  navToggle.addEventListener("click", () => {
    const isOpen = header.classList.toggle("is-menu-open");
    navToggle.setAttribute("aria-expanded", String(isOpen));
  });

  siteNav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", closeMobileMenu);
  });

  window.addEventListener("resize", () => {
    if (window.innerWidth > 980) closeMobileMenu();
  });
}

const modal = document.getElementById("packageModal");
const modalContent = document.getElementById("modalContent");
const modalClose = document.getElementById("modalClose");
const cards = document.querySelectorAll(".interactive-card");
const parksCarousel = document.getElementById("parksCarousel");
const parksPrev = document.getElementById("parksPrev");
const parksNext = document.getElementById("parksNext");
const parksDots = document.getElementById("parksDots");
const packagesCarousel = document.getElementById("packagesCarousel");
const packagesPrev = document.getElementById("packagesPrev");
const packagesNext = document.getElementById("packagesNext");
const packagesDots = document.getElementById("packagesDots");
const accomCarousel = document.getElementById("accomCarousel");
const accomPrev = document.getElementById("accomPrev");
const accomNext = document.getElementById("accomNext");
const accomDots = document.getElementById("accomDots");
const accomLightbox = document.getElementById("accomLightbox");
const accomLightboxImage = document.getElementById("accomLightboxImage");
const accomLightboxClose = document.getElementById("accomLightboxClose");
const accomLightboxPrev = document.getElementById("accomLightboxPrev");
const accomLightboxNext = document.getElementById("accomLightboxNext");
const priceGrid = document.getElementById("priceGrid");
const packagePriceHeadline = document.getElementById("packagePriceHeadline");

const templateMap = {
  "ndutu-calving-6d": "tpl-ndutu-calving-6d",
  "luxury-migration-8d": "tpl-luxury-migration-8d",
  "tanzania-zanzibar-9d": "tpl-tanzania-zanzibar-9d"
};

function openModal(packageKey) {
  const tplId = templateMap[packageKey];
  if (!tplId || !modal || !modalContent) return;
  const tpl = document.getElementById(tplId);
  if (!tpl) return;

  modalContent.innerHTML = "";
  modalContent.appendChild(tpl.content.cloneNode(true));
  modal.classList.add("is-open");
  modal.setAttribute("aria-hidden", "false");
  document.body.classList.add("modal-open");
}

function closeModal() {
  if (!modal || !modalContent) return;
  modal.classList.remove("is-open");
  modal.setAttribute("aria-hidden", "true");
  document.body.classList.remove("modal-open");
  modalContent.innerHTML = "";
}

cards.forEach((card) => {
  card.addEventListener("click", () => openModal(card.dataset.package));
  card.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      openModal(card.dataset.package);
    }
  });
});

if (modalClose) {
  modalClose.addEventListener("click", closeModal);
}

if (modal) {
  modal.addEventListener("click", (event) => {
    if (event.target === modal) closeModal();
  });
}

if (parksCarousel && parksPrev && parksNext) {
  const getStep = () => {
    const firstSlide = parksCarousel.querySelector(".park-slide");
    if (!firstSlide) return Math.max(320, Math.floor(parksCarousel.clientWidth * 0.85));
    const gap = Number.parseFloat(getComputedStyle(parksCarousel).gap || getComputedStyle(parksCarousel).columnGap || "0");
    return firstSlide.clientWidth + gap;
  };

  const getIndex = () => Math.round(parksCarousel.scrollLeft / getStep());

  const syncDots = () => {
    if (!parksDots) return;
    const index = getIndex();
    parksDots.querySelectorAll(".dot").forEach((dot, dotIndex) => {
      dot.classList.toggle("is-active", dotIndex === index);
    });
  };

  parksPrev.addEventListener("click", () => {
    parksCarousel.scrollBy({ left: -getStep(), behavior: "smooth" });
  });

  parksNext.addEventListener("click", () => {
    parksCarousel.scrollBy({ left: getStep(), behavior: "smooth" });
  });

  parksCarousel.addEventListener("scroll", syncDots, { passive: true });

  if (parksDots) {
    parksDots.querySelectorAll(".dot").forEach((dot) => {
      dot.addEventListener("click", () => {
        const index = Number(dot.getAttribute("data-index"));
        parksCarousel.scrollTo({ left: getStep() * index, behavior: "smooth" });
      });
    });
  }

  syncDots();
}

if (packagesCarousel && packagesPrev && packagesNext) {
  const getPackageStep = () => {
    const firstCard = packagesCarousel.querySelector(".interactive-card");
    if (!firstCard) return Math.max(320, Math.floor(packagesCarousel.clientWidth * 0.85));
    const gap = Number.parseFloat(getComputedStyle(packagesCarousel).gap || getComputedStyle(packagesCarousel).columnGap || "0");
    return firstCard.clientWidth + gap;
  };

  const getPackageIndex = () => Math.round(packagesCarousel.scrollLeft / getPackageStep());

  const syncPackageDots = () => {
    if (!packagesDots) return;
    const index = getPackageIndex();
    packagesDots.querySelectorAll(".dot").forEach((dot, dotIndex) => {
      dot.classList.toggle("is-active", dotIndex === index);
    });
  };

  packagesPrev.addEventListener("click", () => {
    packagesCarousel.scrollBy({ left: -getPackageStep(), behavior: "smooth" });
  });

  packagesNext.addEventListener("click", () => {
    packagesCarousel.scrollBy({ left: getPackageStep(), behavior: "smooth" });
  });

  packagesCarousel.addEventListener("scroll", syncPackageDots, { passive: true });

  if (packagesDots) {
    packagesDots.querySelectorAll(".dot").forEach((dot) => {
      dot.addEventListener("click", () => {
        const index = Number(dot.getAttribute("data-index"));
        packagesCarousel.scrollTo({ left: getPackageStep() * index, behavior: "smooth" });
      });
    });
  }

  syncPackageDots();
}

if (accomCarousel && accomPrev && accomNext) {
  const accomLinks = Array.from(accomCarousel.querySelectorAll(".accom-photo"));
  let activeAccomIndex = 0;

  const openAccomLightbox = (index) => {
    if (!accomLightbox || !accomLightboxImage || accomLinks.length === 0) return;
    activeAccomIndex = (index + accomLinks.length) % accomLinks.length;
    const current = accomLinks[activeAccomIndex];
    const image = current.querySelector("img");
    accomLightboxImage.src = current.getAttribute("href") || "";
    accomLightboxImage.alt = image ? image.alt : "Accommodation photo";
    accomLightbox.classList.add("is-open");
    accomLightbox.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
  };

  const closeAccomLightbox = () => {
    if (!accomLightbox || !accomLightboxImage) return;
    accomLightbox.classList.remove("is-open");
    accomLightbox.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
    accomLightboxImage.src = "";
  };

  const nextAccomImage = () => openAccomLightbox(activeAccomIndex + 1);
  const prevAccomImage = () => openAccomLightbox(activeAccomIndex - 1);

  accomLinks.forEach((link, index) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      openAccomLightbox(index);
    });
  });

  if (accomLightboxClose) accomLightboxClose.addEventListener("click", closeAccomLightbox);
  if (accomLightboxNext) accomLightboxNext.addEventListener("click", nextAccomImage);
  if (accomLightboxPrev) accomLightboxPrev.addEventListener("click", prevAccomImage);
  if (accomLightbox) {
    accomLightbox.addEventListener("click", (event) => {
      if (event.target === accomLightbox) closeAccomLightbox();
    });
  }

  const getAccomStep = () => {
    const firstCard = accomCarousel.querySelector(".accom-photo");
    if (!firstCard) return Math.max(320, Math.floor(accomCarousel.clientWidth * 0.85));
    const gap = Number.parseFloat(getComputedStyle(accomCarousel).gap || getComputedStyle(accomCarousel).columnGap || "0");
    return firstCard.clientWidth + gap;
  };

  const getAccomIndex = () => Math.round(accomCarousel.scrollLeft / getAccomStep());

  const syncAccomDots = () => {
    if (!accomDots) return;
    const index = getAccomIndex();
    accomDots.querySelectorAll(".dot").forEach((dot, dotIndex) => {
      dot.classList.toggle("is-active", dotIndex === index);
    });
  };

  accomPrev.addEventListener("click", () => {
    accomCarousel.scrollBy({ left: -getAccomStep(), behavior: "smooth" });
  });

  accomNext.addEventListener("click", () => {
    accomCarousel.scrollBy({ left: getAccomStep(), behavior: "smooth" });
  });

  accomCarousel.addEventListener("scroll", syncAccomDots, { passive: true });

  if (accomDots) {
    accomDots.querySelectorAll(".dot").forEach((dot) => {
      dot.addEventListener("click", () => {
        const index = Number(dot.getAttribute("data-index"));
        accomCarousel.scrollTo({ left: getAccomStep() * index, behavior: "smooth" });
      });
    });
  }

  syncAccomDots();
}

if (priceGrid && packagePriceHeadline) {
  const priceCards = Array.from(priceGrid.querySelectorAll(".price-card"));

  const setActivePriceCard = (card) => {
    const travelers = card.getAttribute("data-travelers") || "";
    const price = card.getAttribute("data-price") || "";
    priceCards.forEach((item) => {
      const isActive = item === card;
      item.classList.toggle("is-active", isActive);
      item.setAttribute("aria-pressed", isActive ? "true" : "false");
    });

    if (travelers === "6+") {
      packagePriceHeadline.innerHTML = `Starting from <strong>${price} per person</strong>`;
      return;
    }

    packagePriceHeadline.innerHTML = `Price for <strong>${travelers} travelers: ${price} per person</strong>`;
  };

  priceCards.forEach((card) => {
    card.addEventListener("click", () => setActivePriceCard(card));
  });
}

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeModal();
    closeMobileMenu();
    if (accomLightbox && accomLightbox.classList.contains("is-open")) {
      accomLightbox.classList.remove("is-open");
      accomLightbox.setAttribute("aria-hidden", "true");
      document.body.classList.remove("modal-open");
      if (accomLightboxImage) accomLightboxImage.src = "";
    }
  }

  if (accomLightbox && accomLightbox.classList.contains("is-open")) {
    if (event.key === "ArrowRight") {
      if (accomLightboxNext) accomLightboxNext.click();
    }
    if (event.key === "ArrowLeft") {
      if (accomLightboxPrev) accomLightboxPrev.click();
    }
  }
});

const filterSearch = document.getElementById("filterSearch");
const filterDestination = document.getElementById("filterDestination");
const filterStyle = document.getElementById("filterStyle");
const filterDays = document.getElementById("filterDays");
const filterBudget = document.getElementById("filterBudget");
const filterBudgetValue = document.getElementById("filterBudgetValue");
const filterBeach = document.getElementById("filterBeach");
const filterApply = document.getElementById("filterApply");
const filterReset = document.getElementById("filterReset");
const packagesExplorerGrid = document.getElementById("packagesExplorerGrid");
const resultsCount = document.getElementById("resultsCount");
const resultsLabel = document.getElementById("resultsLabel");
const packagesEmpty = document.getElementById("packagesEmpty");

if (
  filterSearch &&
  filterDestination &&
  filterStyle &&
  filterDays &&
  filterBudget &&
  filterBudgetValue &&
  filterBeach &&
  filterApply &&
  filterReset &&
  packagesExplorerGrid &&
  resultsCount &&
  resultsLabel &&
  packagesEmpty
) {
  const explorerCards = Array.from(packagesExplorerGrid.querySelectorAll(".package-result-card"));

  const updateBudgetLabel = () => {
    const budget = Number(filterBudget.value);
    filterBudgetValue.textContent = `$${budget.toLocaleString("en-US")}`;
  };

  const applyPackageFilters = () => {
    const searchValue = filterSearch.value.trim().toLowerCase();
    const destinationValue = filterDestination.value;
    const styleValue = filterStyle.value;
    const daysValue = filterDays.value;
    const budgetValue = Number(filterBudget.value);
    const beachValue = filterBeach.checked;

    let visibleCount = 0;

    explorerCards.forEach((card) => {
      const title = (card.getAttribute("data-title") || "").toLowerCase();
      const destinations = (card.getAttribute("data-destinations") || "").toLowerCase();
      const style = (card.getAttribute("data-style") || "").toLowerCase();
      const days = Number(card.getAttribute("data-days") || "0");
      const rawPrice = card.getAttribute("data-price") || "";
      const price = Number(rawPrice);
      const hasPrice = rawPrice !== "" && !Number.isNaN(price) && price > 0;
      const beach = card.getAttribute("data-beach") === "true";

      const matchesSearch = !searchValue || title.includes(searchValue) || destinations.includes(searchValue);
      const matchesDestination = destinationValue === "all" || destinations.includes(destinationValue);
      const matchesStyle = styleValue === "all" || style === styleValue;
      const matchesDays = daysValue === "all" || days <= Number(daysValue);
      const matchesBudget = !hasPrice || price <= budgetValue;
      const matchesBeach = !beachValue || beach;

      const isVisible = matchesSearch && matchesDestination && matchesStyle && matchesDays && matchesBudget && matchesBeach;
      card.classList.toggle("is-filtered-out", !isVisible);
      card.hidden = !isVisible;
      if (isVisible) visibleCount += 1;
    });

    resultsCount.textContent = String(visibleCount);
    resultsLabel.textContent = visibleCount === 1 ? "package" : "packages";
    packagesEmpty.hidden = visibleCount > 0;
  };

  const resetPackageFilters = () => {
    filterSearch.value = "";
    filterDestination.value = "all";
    filterStyle.value = "all";
    filterDays.value = "all";
    filterBudget.value = "8000";
    filterBeach.checked = false;
    updateBudgetLabel();
    applyPackageFilters();
  };

  filterBudget.addEventListener("input", updateBudgetLabel);

  filterApply.addEventListener("click", applyPackageFilters);
  filterSearch.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      applyPackageFilters();
    }
  });

  filterReset.addEventListener("click", resetPackageFilters);

  updateBudgetLabel();
  applyPackageFilters();
}
